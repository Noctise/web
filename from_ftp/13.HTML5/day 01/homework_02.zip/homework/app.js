//1:加载相应的模块 http mysql express querystring
const http = require("http");
const mysql = require("mysql");
const express = require("express");
const qs = require("querystring");

var pool = mysql.createPool({
  host:"127.0.0.1",
  user:"root",
  password:"",
  database:"dangdang"
});
//2:创建服务器
//3:绑定监听端口
var app = express();
var server = http.createServer(app);
server.listen(8080);

//处理静态文件 html/css/js
//添加中间件->作用处理静态资源文件
//所有文件public
//示例:
// http://127.0.0.1:8080/booklist.html
// http://127.0.0.1:8080/addbook.html
app.use(express.static("public"));

//1:处理请求 GET /book
//a:处理请求 get /book
app.get("/book",(req,res)=>{
 //b:获取数据库连接
 pool.getConnection((err,conn)=>{
  //c:创建SQL,并且发送SQL
  var sql = "SELECT * FROM book";
  conn.query(sql,(err,result)=>{
   if(err)throw err;
   //d:result [{],{}]
   //e:将结果发送客户json
   res.json(result);
   conn.release();
  });
 });
});

//功能:能够处理静态请求 静态资源public
//     能够处理动态请求 /salesdata json
//1:加载相应的模块 http express
const http = require("http");
const express = require("express");

//2:创建服务器 express server
var app = express();
var server = http.createServer(app);
server.listen(8080);

//3:加载处理静态资源中间件 public
app.use(express.static("public"));
//4:处理动态请求 get/salesdata  json
app.get("/salesdata",(req,res)=>{
  var data = [
    {label:"部门1",value:100},
    {label:"部门2",value:200},
    {label:"部门3",value:150},
    {label:"部门4",value:190}
   ];
  res.json(data);
});


//1:加载相应模块 mysql http express querystring
//  创建连接池
const mysql = require("mysql");
const http = require("http");
const express = require("express");
const qs = require("querystring");
var pool = mysql.createPool({
  host:"127.0.0.1",
  user:"root",
  password:"",
  database:"bbs",
  connectionLimit:10
});
//2:创建服务器 
//3:绑定端口 8080
var app = express();
var server = http.createServer(app);
server.listen(8080);
//4:处理静态内容请求的中间件
app.use(express.static("public"));

//5:处理动态内容 post /addmsg
app.post("/addmsg",(req,res)=>{
    //5.1 获取用户提交参数 uname content
    req.on("data",(data)=>{
      //5.2 处理函数 用户参数提交完成
      //Buffer->string->js Object
      //[00 0a 01 aa]=>'uname=tom&content=hello'
      //{uname:'tom',content:'hello'}
      //obj.uname   obj.content
      var obj = qs.parse(data.toString());
      //5.3:获取连接
      pool.getConnection((err,conn)=>{
      //5.4:创建sql
      var sql = "INSERT INTO msg VALUES(null,?,?,?)";
      //5.5:发送sql
      conn.query(sql,
        [obj.uname,obj.content,
        new Date().getTime()],
        (err,result)=>{
        //5.6 如果添加成功返回 json
        if(result.affectedRows > 0){
          res.json({code:1,msg:"添加成功",mid:result.insertId});
          conn.release();
        }
      });
      //5.6:如果成功 json obj      
      });
    });
});

//6:处理动态内容 get /msg
app.get("/msg",(req,res)=>{
  //6.1 获取连接
  pool.getConnection((err,conn)=>{
   //6.2 创建sql语句并且发送sql
   var sql = "SELECT * FROM msg";
   //6:3 result 
   conn.query(sql,(err,result)=>{
      res.json(result);
      conn.release();
   });
  });

});




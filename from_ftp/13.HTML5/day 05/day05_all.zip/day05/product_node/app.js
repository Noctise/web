//1:加载相应模块 http express
const http = require("http");
const express = require("express");
//2:创建express对象
var app = express();
//3:创建web服务器，参数app
var server = http.createServer(app);
//4:绑定监听端口
server.listen(8080);

//5:先处理客户端静态请求
app.use(express.static("public"));
//6:处理客户端动态请求  get /start
app.get("/start",(req,res)=>{
  var data = [
    {label:"HTML",value:4},
    {label:"JS",value:7},
    {label:"DOM",value:8},    
    {label:"AJAX",value:9}
  ];
  res.json(data);
});

